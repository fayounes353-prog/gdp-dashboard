import streamlit as st
from google import genai
from google.genai import types

st.set_page_config(page_title="MY AI AGENT", page_icon="🤖", layout="wide")

st.markdown("""
<style>
.block-container {max-width: 950px; padding-top: 2rem;}
.hero {padding: 1.4rem; border-radius: 18px; background: linear-gradient(120deg,#101827,#243b63); color:white;}
.small {opacity:.8}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>🤖 MY AI AGENT</h1><p class="small">Your personal AI workspace</p></div>', unsafe_allow_html=True)
st.write("Ask, plan, write, analyze, and create. You stay in control of actions that affect your accounts or money.")

api_key = st.sidebar.text_input("Gemini API key", type="password", help="Paste your key here. It is used only for this app session.")
model = st.sidebar.selectbox("AI model", ["gemini-2.5-flash", "gemini-2.0-flash"], index=0)
st.sidebar.caption("Never share your API key in chat or publish it in GitHub.")
if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

prompt = st.chat_input("What should I help you do?")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    with st.chat_message("assistant"):
        if not api_key:
            answer = "Add your Gemini API key in the sidebar to activate the AI."
            st.info(answer)
        else:
            try:
                client = genai.Client(api_key=api_key)
                history = []
                for m in st.session_state.messages[:-1]:
                    role = "user" if m["role"] == "user" else "model"
                    history.append(types.Content(role=role, parts=[types.Part(text=m["content"])]))
                response = client.models.generate_content(
                    model=model,
                    contents=history + [types.Content(role="user", parts=[types.Part(text=prompt)])],
                    config=types.GenerateContentConfig(
                        system_instruction=(
                            "You are MY AI AGENT, a practical assistant. Help plan and execute tasks "
                            "by producing clear steps, drafts, code, and checklists. Be honest about "
                            "what you cannot access or do. Never claim to have sent, posted, purchased, "
                            "deleted, or changed anything unless an authorized tool actually did it. "
                            "Ask for confirmation before consequential actions. Reply in the user's language."
                        ),
                        temperature=0.5
                    )
                )
                answer = response.text or "I couldn't generate a response. Please try again."
                st.markdown(answer)
            except Exception as e:
                answer = f"Connection error: {e}"
                st.error(answer)
    st.session_state.messages.append({"role": "assistant", "content": answer})

if st.session_state.messages and st.button("Clear conversation"):
    st.session_state.messages = []
    st.rerun()
