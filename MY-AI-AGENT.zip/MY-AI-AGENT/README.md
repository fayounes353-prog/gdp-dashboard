# MY AI AGENT

A small Streamlit AI workspace powered by Google's Gemini API.

## Run locally
1. Install Python 3.10 or newer.
2. In this folder run: `pip install -r requirements.txt`
3. Run: `streamlit run app.py`
4. Paste your Gemini API key into the sidebar.

## Deploy on Streamlit Community Cloud
1. Push these files to a GitHub repository.
2. In Streamlit Community Cloud, create an app using `app.py` as the main file.
3. Deploy. Add your Gemini API key in the app's Settings > Secrets if you later switch the app to read secrets.
   The starter version accepts the key in the sidebar for the current session.

## Important
This starter app is an AI chat workspace, not an unrestricted autonomous agent.
It does not log into websites, publish content, spend money, or control accounts.
Add integrations only with explicit authorization and secure credentials.
